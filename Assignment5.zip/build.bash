#!/bin/bash
set -e -v
echo "Compiling..."
javac *.java
echo "To run: java Main"
